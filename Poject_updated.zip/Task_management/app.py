
from flask import Flask, request, redirect, url_for, render_template, flash, session, jsonify
import sqlite3
from datetime import datetime, timedelta
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Initialize the database
def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_info (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            firstname TEXT NOT NULL,
            lastname TEXT NOT NULL,
            gender TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def create_task_table(table_name):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f'''
        CREATE TABLE IF NOT EXISTS {table_name} (
            task_id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_description TEXT NOT NULL,
            task_status TEXT NOT NULL,
            task_datetime TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def login_form():
    return render_template('login.html')

@app.route('/signup')
def signup_form():
    return render_template('signup.html')

@app.route('/signup-success', methods=['POST'])
def signup_success():
    firstname = request.form['firstname']
    lastname = request.form['lastname']
    gender = request.form['gender']
    email = request.form['email']
    password = request.form['psw']
    password_repeat = request.form['psw-repeat']

    # Server-side validation
    if password != password_repeat:
        flash("Passwords mismatch")
        return redirect(url_for('signup_form'))

    if not firstname.isalpha() or not lastname.isalpha():
        flash("First name and Last name should only contain letters.")
        return redirect(url_for('signup_form'))

    if len(password) < 8:
        flash("Password must be at least 8 characters long.")
        return redirect(url_for('signup_form'))

    # Check if email already exists
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM user_info WHERE email = ?', (email,))
    existing_user = cursor.fetchone()
    if existing_user:
        flash("This email is already registered.")
        conn.close()
        return redirect(url_for('signup_form'))

    # Save data to database
    cursor.execute('''
        INSERT INTO user_info (firstname, lastname, gender, email, password)
        VALUES (?, ?, ?, ?, ?)
    ''', (firstname, lastname, gender, email, password))
    conn.commit()

    # Create task table for the new user
    user_id = cursor.lastrowid
    table_name = f"{firstname}_{user_id}"
    create_task_table(table_name)
    conn.close()

    return redirect(url_for('login_form'))

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['psw']

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM user_info WHERE email = ? AND password = ?', (email, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        session['user_id'] = user[0]
        session['user_firstname'] = user[1]
        # flash("Login successful!")  # Commented out to remove the flash message
        return redirect(url_for('home'))
    else:
        flash("Invalid email or password.")
        return redirect(url_for('login_form'))

@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    user_id = session['user_id']
    user_firstname = session['user_firstname']
    table_name = f"{user_firstname}_{user_id}"

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f'SELECT task_id, task_description, task_status FROM {table_name} ORDER BY task_id DESC LIMIT 5')
    tasks = cursor.fetchall()
    conn.close()

    tasks = [{'task_id': task[0], 'task_description': task[1], 'task_status': task[2]} for task in tasks]

    return render_template('home.html', user={'firstname': user_firstname}, tasks=tasks)

@app.route('/all-tasks')
def all_tasks():
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    user_id = session['user_id']
    user_firstname = session['user_firstname']
    table_name = f"{user_firstname}_{user_id}"

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f'SELECT task_id, task_description, task_status FROM {table_name}')
    tasks = cursor.fetchall()
    conn.close()

    tasks = [{'task_id': task[0], 'task_description': task[1], 'task_status': task[2]} for task in tasks]

    return render_template('all_tasks.html', tasks=tasks)

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    user_id = session['user_id']
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM user_info WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()

    return render_template('profile.html', user={
        'firstname': user[1],
        'lastname': user[2],
        'email': user[4]
    })

@app.route('/task/<int:task_id>')
def task_detail(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    user_id = session['user_id']
    user_firstname = session['user_firstname']
    table_name = f"{user_firstname}_{user_id}"

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f'SELECT task_id, task_description, task_status FROM {table_name} WHERE task_id = ?', (task_id,))
    task = cursor.fetchone()
    conn.close()

    if not task:
        return "Task not found."

    return render_template('task.html', task={
        'task_id': task[0],
        'task_description': task[1],
        'task_status': task[2]
    })

@app.route('/add-task', methods=['GET', 'POST'])
def add_task():
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    if request.method == 'POST':
        task_description = request.form['task_description']
        task_status = request.form['task_status']
        task_datetime = request.form['task_datetime']
        formatted_task_datetime = task_datetime.replace("T", " ") + ":00"

        user_id = session['user_id']
        user_firstname = session['user_firstname']
        table_name = f"{user_firstname}_{user_id}"

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute(f'''
            INSERT INTO {table_name} (task_description, task_status, task_datetime)
            VALUES (?, ?, ?)
        ''', (task_description, task_status, formatted_task_datetime))
        conn.commit()
        conn.close()

        return redirect(url_for('home'))

    return render_template('add_task.html')

@app.route('/update-task/<int:task_id>', methods=['POST'])
def update_task(task_id):
    if 'user_id' not in session:
        return redirect(url_for('login_form'))

    task_status = request.form['status']
    user_id = session['user_id']
    user_firstname = session['user_firstname']
    table_name = f"{user_firstname}_{user_id}"

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f'''
        UPDATE {table_name}
        SET task_status = ?
        WHERE task_id = ?
    ''', (task_status, task_id))
    conn.commit()
    conn.close()

    return redirect(url_for('task_detail', task_id=task_id))

# @app.route('/logout')
# def logout():
#     session.clear()
#     return redirect(url_for('login_form'))

@app.route('/logout', methods=['GET'])
def logout():
    # Clear session or logout logic here
    session.clear()  # Example of clearing session data
    return redirect(url_for('login'))  # Redirect to login page

@app.route('/check-tasks')
def check_tasks():
    if 'user_id' not in session:
        return jsonify([])

    user_id = session['user_id']
    user_firstname = session['user_firstname']
    table_name = f"{user_firstname}_{user_id}"

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    later = (datetime.now() + timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute(f"SELECT task_id, task_description, task_status, task_datetime FROM {table_name} WHERE task_datetime BETWEEN ? AND ?", (now, later))
    tasks = cursor.fetchall()
    conn.close()

    tasks = [{'task_id': task[0], 'task_description': task[1], 'task_status': task[2], 'task_datetime': task[3]} for task in tasks]
    print(tasks)
    return jsonify(tasks)

@app.route('/check-email', methods=['POST'])
def check_email():
    email = request.json.get('email')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM user_info WHERE email = ?', (email,))
    existing_user = cursor.fetchone()
    conn.close()

    if existing_user:
        return jsonify({'exists': True}), 200
    else:
        return jsonify({'exists': False}), 200

if __name__ == '__main__':
    app.run(debug=True)
