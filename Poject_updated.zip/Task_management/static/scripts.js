$(document).ready(function() {
    function fetchTasks() {
        $.get('/check-tasks', function(data) {
            if (data.length > 0) {
                let i = 0;

                function showTask() {
                    if (i < data.length) {
                        let task = data[i];
                        alert('Task: ' + task.task_description + ' is at ' + task.task_datetime);
                        i++;
                        setTimeout(showTask, 2000); // 2 seconds delay between pop-ups
                    }
                }

                showTask();
            }
        });
    }

    fetchTasks(); // Fetch and show tasks when the page loads
});
//$(document).ready(function() {
//    var displayedTasks = []; // Array to store task IDs that have been displayed
//
//    function fetchAndDisplayTasks() {
//        $.get('/check-tasks', function(tasks) {
//            tasks.forEach(function(task) {
//                if (!displayedTasks.includes(task.task_id)) {
//                    // Create and display a Bootstrap Toast for each new task
//                    var toastHTML = `
//                    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="5000">
//                        <div class="toast-header">
//                            <strong class="mr-auto">New Task</strong>
//                            <small>${task.task_datetime}</small>
//                            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
//                                <span aria-hidden="true">&times;</span>
//                            </button>
//                        </div>
//                        <div class="toast-body">
//                            ${task.task_description}
//                        </div>
//                    </div>
//                    `;
//
//                    $('#toast-container').append(toastHTML); // Append toast to container
//                    $('#toast-container .toast:last').toast('show'); // Show the toast
//
//                    displayedTasks.push(task.task_id); // Add task ID to displayedTasks array
//                }
//            });
//        });
//    }
//
//    // Function to periodically fetch tasks
//    function periodicTaskCheck() {
//        fetchAndDisplayTasks(); // Fetch tasks initially when the page loads
//
//        // Fetch tasks every 2 minutes (adjust as needed)
//        setInterval(fetchAndDisplayTasks, 2 * 60 * 1000); // 2 minutes in milliseconds
//    }
//
//    // Call periodicTaskCheck() to start checking for tasks
//    periodicTaskCheck();
//});
